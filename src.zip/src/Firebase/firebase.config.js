// console.log(process.env)
const firebaseConfig = {
    apiKey: "AIzaSyAYNScUJOxF1jdYDoOfS0p8ovwQP5LQlcM",
    authDomain: "doccure-d0774.firebaseapp.com",
    projectId: "doccure-d0774",
    storageBucket: "doccure-d0774.appspot.com",
    messagingSenderId: "495100378143",
    appId: "1:495100378143:web:5773f4e7c06d42c99de92a"
    // apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
    // authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
    // projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID,
    // storageBucket: process.env.REACT_APP_FIREBASE_STORAGE_BUCKET,
    // messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGING_SENDER_ID,
    // appId: process.env.REACT_APP_FIREBASE_APPID
};
export default firebaseConfig;